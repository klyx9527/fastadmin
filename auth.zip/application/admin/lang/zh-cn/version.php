<?php

return [
    'id'          => 'ID',
    'oldversion'  => '旧版本号',
    'newversion'  => '新版本号',
    'packagesize' => '包大小',
    'content'     => '升级内容',
    'downloadurl' => '下载地址',
    'enforce'     => '强制更新',
    'createtime'  => '创建时间',
    'updatetime'  => '更新时间',
    'weigh'       => '权重',
    'status'      => '状态'
];
