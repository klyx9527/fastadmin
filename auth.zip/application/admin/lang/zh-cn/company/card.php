<?php

return [
    'id'  =>  'id',
    'name'  =>  '姓名',
    'tel'  =>  '电话',
    'webchat'  =>  '微信',
    'relname'  =>  '别名',
    'createtime'  =>  '创建日期',
    'updatetime'  =>  '更新日期',
    'babytime'  =>  '出生日期',
    'remark'  =>  '备注',
    'content'  =>  '内容',
    'staff_id'  =>  '员工表关联字段',
    'channel_id'  =>  '渠道表关联字段',
    'staff.name' => '员工名字',
    'channel.name' => '渠道名字'
];
