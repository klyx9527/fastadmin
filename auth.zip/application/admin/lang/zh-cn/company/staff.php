<?php

return [
    'id'  =>  'id',
    'name'  =>  '姓名',
    'pid'  =>  '父id',
    'tel'  =>  '电话',
    'type'  =>  '栏目类型',
    'nikename'  =>  '昵称',
    'diyname'  =>  '别名',
    'createtime'  =>  '创建时间',
    'updatetime'  =>  '更新时间',
    'status'  =>  '状态',
    'cardid'  =>  '关联字段'
];
