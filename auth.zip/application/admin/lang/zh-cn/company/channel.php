<?php

return [
    'id'  =>  'id',
    'chaname'  =>  '渠道',
    'pid'  =>  '父id',
    'payment'  =>  '投放',
    'data'  =>  '获取资料',
    'cost'  =>  '成本',
    'num'  =>  '订单数',
    'nominal'  =>  '金额',
    'average'  =>  '均价',
    'ordercost'  =>  '订单成本',
    'Rates'  =>  '百分比'
];
