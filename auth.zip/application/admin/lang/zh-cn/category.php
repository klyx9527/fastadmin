<?php

return [
    'Diyname'     => '自定义别名',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'keywords'    => '关键字',
];
