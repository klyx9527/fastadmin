<?php

return [
    'The parent group can not be its own child'                            => '父组别不能是自身的子组别',
    'The parent group can not found'                                       => '父组别未找到',
    'You can not delete group that contain child group and administrators' => '你不能删除含有子组和管理员的组',
];
