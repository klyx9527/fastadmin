<?php

return [
    'id'          => 'ID',
    'category_id' => '分类ID',
    'title'       => '标题',
    'keywords'    => '关键字',
    'flag'        => '标志',
    'image'       => '头像',
    'content'     => '内容',
    'icon'        => '图标',
    'views'       => '点击',
    'comments'    => '评论',
    'weigh'       => '权重',
    'status'      => '状态'
];
