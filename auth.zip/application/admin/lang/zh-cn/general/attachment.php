<?php

return [
    'Url'         => '物理路径',
    'Imagewidth'  => '宽度',
    'Imageheight' => '宽度',
    'Imagetype'   => '图片类型',
    'Imageframes' => '图片帧数',
    'Filesize'    => '文件大小',
    'Mimetype'    => 'mime类型',
    'Extparam'    => '透传数据',
    'Createtime'  => '创建日期',
    'Uploadtime'  => '上传时间'
];
