<?php

return [
    'Title'        => '任务标题',
    'Maximums'     => '最多执行',
    'Sleep'        => '延迟秒数',
    'Schedule'     => '执行周期',
    'Executes'     => '执行次数',
    'Execute time' => '执行时间',
];
