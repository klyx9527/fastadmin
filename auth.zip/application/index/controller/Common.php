<?php

namespace app\index\controller;

use app\common\controller\Frontend;

/**
 * 公共控制器
 */
class Common extends Frontend
{

    public function _initialize()
    {
        parent::_initialize();
    }

}
