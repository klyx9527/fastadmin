<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'OTHER',
    'name' => 'FastAdmin',
    'url' => 'http://www.fa.com/index/ucenter',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'index',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'DISCUZX',
    'name' => 'Discuz!',
    'url' => 'http://www.discuz.com',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'utf-8',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://www.ucenter.com',
);
